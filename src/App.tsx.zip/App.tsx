import React, {useState, useEffect} from "react";

import './App.css';
import '../node_modules/rsuite/dist/rsuite.min.css';
import { pv } from 'financial'
//import { Slider, RangeSlider } from 'rsuite';

// Usage
function App() {

  const [principal, setPrincipal] = useState<number>(50020);
  const [rate, setRate] = useState<number>(5.75);
  const [term, setTerm] = useState<number>(30);
  const [other, setOther] = useState<number>(500);
  const [pi, setPI] = useState<number>(1167.15);
  const [taxes, setTaxes] = useState<number>(166.67);
  const [pmi, setPMI] = useState<number>(20.00);
  const [insurance, setInsurance] = useState<number>(83.33);
  const [debts, setDebts] = useState<number>(0);
  const [income, setIncome] = useState<number>(72000);
  const [payment, setPayment] = useState<number>(0);
  const [dti, setDTI] = useState<number>(36);

  const maxAffordability = 0.20;
  //const maxdti = useState<number>(36);

  const [fieldsValidation, setFieldsValidation] = useState<string[]>(["hidden","hidden"]);

  function validateIsCurrency(val :string, index :number) {
    const isValid = /(?=.*?\d)^\$?(([1-9]\d{0,2}(,\d{3})*)|\d+)?(\.\d{1,2})?$/.test(val);
    setFieldsValidation(fieldsValidation.map((temp,i) => {
      if(i===index) return (isValid?"hidden":"shown");
      else return temp;
    }));

    return isValid;
  }
  
  useEffect(() => {

    let myPayment = (income/12)*maxAffordability;

    setPayment(Math.round(myPayment * 100)/100);


    /*

    This is the reverse engineered formula, it comes out close but a bit different. Keeeping in a comment for now.

    let i = (rate/100)/12;
    let n = term*12;
    let x = payment / (( i * (1 + i)**n ) / ( (1 + i)**n - 1));
    */
    let actualRate = (rate/100)/12;
    let actualTerm = term*12;

    let myPrincipal = pv(actualRate, actualTerm, -myPayment);
    
    setPrincipal(Math.round(myPrincipal * 100)/100);

    setDebts(pi+taxes+pmi+insurance);
    let myDTI =  (debts+principal+other)/(income/12);

    setDTI(Math.round(myDTI*10000)/100);
  }, [principal, rate, term, payment, debts, income, other, dti, insurance, pi, taxes, pmi]);

  return (
    <div>
      <ul>
        <li>
          <label htmlFor="income">Income ($ annual): </label>
          <label htmlFor="income" className={"error " + fieldsValidation[0]}>Error message</label>
          <input type="tel" name="income" defaultValue={income} onChange={(ev)=> {
            
            if (validateIsCurrency(ev.target.value, 0)) {
              setIncome(Number(ev.target.value));
            }
            console.log(fieldsValidation);
          }}></input>
        </li>
        <li>
          <label htmlFor="rate">Rate (%): </label>
          <input type="tel" name="rate" defaultValue={rate} onChange={(ev)=> {
            setRate(Number(ev.target.value));
          }}></input>
        </li>
        <li>
          <label htmlFor="term">Term (years): </label>
          <input type="tel" name="term" defaultValue={term} onChange={(ev)=> {
            setTerm(Number(ev.target.value));
          }}></input>
        </li>
        <li>
          <label htmlFor="other">Other ($): </label>
          <input type="tel" name="other" defaultValue={other} onChange={(ev)=> {
            setOther(Number(ev.target.value));
          }}></input>
        </li>
        <li>
          <label htmlFor="debts">P+I ($): </label>
          <input type="tel" name="pi" defaultValue={pi} onChange={(ev)=> {
            setPI(Number(ev.target.value));
          }}></input>
        </li>
        <li>
          <label htmlFor="taxes">Taxes ($): </label>
          <input type="tel" name="taxes" defaultValue={taxes} onChange={(ev)=> {
            setTaxes(Number(ev.target.value));
          }}></input>
        </li>
        <li>
          <label htmlFor="pmi">PMI ($): </label>
          <input type="tel" name="pmi" defaultValue={pmi} onChange={(ev)=> {
            setPMI(Number(ev.target.value));
          }}></input>
        </li>
        <li>
          <label htmlFor="insurance">Insurance ($): </label>
          <input type="tel" name="insurance" defaultValue={insurance} onChange={(ev)=> {
            setInsurance(Number(ev.target.value));
          }}></input>
        </li>
      </ul>

      <p>
        Payment: {payment}
      </p>
      <p>
        Principal: {principal}
      </p>
      <p>
        Total Debt Ratio: {dti}
      </p>
    </div>
  );
}

export default App;